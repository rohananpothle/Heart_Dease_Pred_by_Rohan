# Training script
print('Training model...')